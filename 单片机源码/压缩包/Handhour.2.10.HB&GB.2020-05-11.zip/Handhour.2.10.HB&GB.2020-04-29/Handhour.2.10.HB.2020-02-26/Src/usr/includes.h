#ifndef __INCLUDES_H
#define __INCLUDES_H

	#ifdef __cplusplus
	 extern "C" {
	#endif


		 
	#ifdef __cplusplus
	}
	#endif	





#endif