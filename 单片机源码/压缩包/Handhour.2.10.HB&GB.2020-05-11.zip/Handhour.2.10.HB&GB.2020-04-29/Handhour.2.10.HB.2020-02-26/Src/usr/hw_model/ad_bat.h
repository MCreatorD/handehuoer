#ifndef __AD_BAT_H_
#define __AD_BAT_H_
	#ifdef __cplusplus
	 extern "C" {
	#endif



	#ifdef __cplusplus
	}
	#endif
#endif
	