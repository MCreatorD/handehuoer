#include "model_base.h"

Model_Base::Model_Base()
{
}

Model_Base::~Model_Base(){

}

int Model_Base::dealMfeMessage(CMessage *pMessage,Base_Comm *pComm){
	
	return -1;
}