#ifndef EXTENDLLRP_MESSAGE_ID
#define EXTENDLLRP_MESSAGE_ID

#define ManufacturerCommand 1000
#define ManufacturerCommandAck 1001
#define ManufacturerReport 1002
#define ManufacturerReportAck 1003

#endif // EXTENDLLRP_MESSAGE_ID

