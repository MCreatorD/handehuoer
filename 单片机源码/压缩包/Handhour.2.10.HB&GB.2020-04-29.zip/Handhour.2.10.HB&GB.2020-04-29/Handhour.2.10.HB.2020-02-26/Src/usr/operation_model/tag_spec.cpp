#include "tag_spec.h"

Tag_Spec::Tag_Spec()
{
}
