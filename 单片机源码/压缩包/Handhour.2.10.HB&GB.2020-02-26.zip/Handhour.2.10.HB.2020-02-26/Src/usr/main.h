#ifndef __MAIN__H
#define __MAIN__H

//���а�͵��԰�
//#define __debug

void Beep_Times(unsigned char n_times);
void Beep_Delay(unsigned short ms);

#endif
