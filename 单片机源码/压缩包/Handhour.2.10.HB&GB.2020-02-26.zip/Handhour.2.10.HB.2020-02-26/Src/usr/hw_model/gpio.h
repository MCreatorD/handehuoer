#ifndef __GPIO_H__
#define __GPIO_H__

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include <stdint.h>

//GPIO��

	#ifdef __cplusplus
	 extern "C" {
	#endif
	 
		

		void GPIO_Configuration(void);
		
	#ifdef __cplusplus
	}
	#endif	

#endif