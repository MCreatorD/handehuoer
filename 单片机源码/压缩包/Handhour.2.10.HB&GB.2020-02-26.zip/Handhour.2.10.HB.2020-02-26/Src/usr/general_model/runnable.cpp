#include "runnable.h"

Runnable::Runnable()
{
}

void Runnable::run(){

}
