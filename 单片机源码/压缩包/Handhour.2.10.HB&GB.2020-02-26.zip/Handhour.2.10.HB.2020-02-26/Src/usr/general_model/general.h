#ifndef GENERAL_H
#define GENERAL_H

#define RF_USE_HBFPGA            		 		1
#define RF_USE_GBFPGA                           0
//1��Ч
#endif // GENERAL_H
